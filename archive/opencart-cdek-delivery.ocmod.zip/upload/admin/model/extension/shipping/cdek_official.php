<?php
class ModelExtensionShippingCdekOfficial extends Model {
    // Custom functions related to the extension
}