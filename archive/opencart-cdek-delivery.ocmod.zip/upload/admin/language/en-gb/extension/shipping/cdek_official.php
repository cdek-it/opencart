<?php
$_['heading_title']    = 'CDEK Delivery Shipping Method';
$_['text_success']     = 'Success: You have modified CDEK Shipping settings!';