<?php

class Sender
{
    public string $company;
    public string $name;
    public string $email;
    public string $passportSeries;
    public string $passportNumber;
    public string $passportDateOfIssue;
    public string $passportOrganization;
    public string $tin;
    public string $passportDateOfBirth;

}