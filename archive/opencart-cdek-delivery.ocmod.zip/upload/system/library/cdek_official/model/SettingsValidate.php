<?php

interface SettingsValidate
{
    public function validate();
}