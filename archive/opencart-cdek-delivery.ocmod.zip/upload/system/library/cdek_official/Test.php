<?php

class Test
{
    public function test()
    {
        return 'work';
    }
}