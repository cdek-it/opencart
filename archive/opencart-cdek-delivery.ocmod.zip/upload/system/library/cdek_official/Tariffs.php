<?php

class Tariffs
{
    const tariffs = [
        ['name' => 'Посылка склад-склад', 'code' => 136, 'enable' => true],
        ['name' => 'Посылка склад-дверь', 'code' => 137, 'enable' => true],
        ['name' => 'Посылка дверь-склад', 'code' => 138, 'enable' => false],
        ['name' => 'Посылка дверь-дверь', 'code' => 139, 'enable' => false],
    ];
}