<?php

namespace CDEK\model;

interface SettingsValidate
{
    public function validate();
}