<?php
$_['text_title']       = 'CDEK Official Shipping';
$_['text_description'] = 'Описание метода доставки CDEK Official';
$_['cdek_shipping__tariff_name_plug'] = 'CDEK плагин';
$_['cdek_shipping__tariff_name_136'] = 'Посылка склад-склад';
$_['cdek_shipping__tariff_name_137'] = 'Посылка склад-дверь';
$_['cdek_shipping__tariff_name_138'] = 'Дверь-склад посылка';
$_['cdek_shipping__tariff_name_139'] = 'Дверь-дверь посылка';
$_['cdek_pvz_not_found'] = 'ПВЗ не найден, выберите ПВЗ на карте';
$_['cdek_shipping__tariff_name_366'] = 'Посылка дверь-постамат';
$_['cdek_shipping__tariff_name_368'] = 'Посылка склад-постамат';
$_['thousand_point'] = ',';
$_['decimal_point'] = ',';