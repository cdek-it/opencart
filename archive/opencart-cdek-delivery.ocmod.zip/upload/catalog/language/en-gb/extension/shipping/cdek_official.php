<?php
$_['text_title']       = 'CDEK Official Shipping';
$_['text_description'] = 'CDEK Official Shipping Method Description';
$_['cdek_shipping__tariff_name_plug'] = 'CDEK plug';
$_['cdek_shipping__tariff_name_136'] = 'Parcel warehouse-warehouse';
$_['cdek_shipping__tariff_name_137'] = 'Parcel warehouse-door';
$_['cdek_shipping__tariff_name_138'] = 'Door-to-warehouse parcel';
$_['cdek_shipping__tariff_name_139'] = 'Door-to-door parcel';
$_['cdek_shipping__tariff_name_366'] = 'Door-to-postamat parcel';
$_['cdek_shipping__tariff_name_368'] = 'Warehouse-to-postamat parcel';
$_['cdek_pvz_not_found'] = 'Office not found, select office on the map';
$_['cdek_pvz_not_from_selected_city'] = 'The selected office is not from the destination city. Change the city in the office settings and specify the correct office to place the order. Or select a office from the selected city';