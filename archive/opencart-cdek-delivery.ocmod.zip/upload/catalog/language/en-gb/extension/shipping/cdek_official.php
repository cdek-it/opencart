<?php
$_['text_title']       = 'CDEK Official Shipping';
$_['text_description'] = 'CDEK Official Shipping Method Description';