<?php
$_['text_title']       = 'CDEK Official Shipping';
$_['text_description'] = 'CDEK Official Shipping Method Description';
$_['cdek_shipping__tariff_name_plug'] = 'CDEK plug';
$_['cdek_shipping__tariff_name_136'] = 'Parcel warehouse-warehouse';
$_['cdek_shipping__tariff_name_137'] = 'Parcel warehouse-door';
$_['cdek_shipping__tariff_name_138'] = 'Door-to-warehouse parcel';
$_['cdek_shipping__tariff_name_139'] = 'Door-to-door parcel';