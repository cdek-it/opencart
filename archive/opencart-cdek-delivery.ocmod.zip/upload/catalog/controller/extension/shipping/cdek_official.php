<?php
class ControllerExtensionShippingCdekOfficial extends Controller {
    public function cdek_official_checkout_shipping(&$route, &$data, &$output)
    {
//        $customContent = $this->load->view('extension/shipping/cdek_official_create_order', $data);

//        $customContent = "<div>CUSTOM</div>";
//
//        $search = '</div>
//{% endfor %}
//{% else %}
//<div class="alert alert-danger alert-dismissible">{{ shipping_method.error }}</div>';
//        $replace = $search . $customContent;
//
//        $offset = 0;
//        $count = 0;
//        $limit = 1;
//
//        while (($pos = strpos($output, $search, $offset)) !== false) {
//            $count++;
//            $offset = $pos + 1;
//            if ($count === $limit) {
//                $output = substr_replace($output, $replace, $pos, strlen($search));
//                break;
//            }
//        }

        $output = "<div>CUSTOM BEFORE</div>";
    }

    public function cdek_official_checkout_shipping_after(&$route, &$data, &$output)
    {
        $customContent = '<div class="radio">  <label><input type="radio" name="shipping_method" value="flat.flat">CDEKCDEKCDEK - $5.00</label></div>';

        $search = '<p><strong>CDEK Official Shipping</strong></p>';
        $pos = strpos($output, $search); // Find the first occurrence of the search string

        if ($pos !== false) {
            $insertPos = $pos + strlen($search); // Position where the custom content will be inserted
            $output = substr_replace($output, $customContent, $insertPos, 0);
        }
    }
}